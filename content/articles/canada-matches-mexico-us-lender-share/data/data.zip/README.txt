Canada matches Mexico on its US lender share but borrows far more against its exports
=====================================================================================

The data behind this datasteg data note, as the desk read them when it wrote the note.

numbers.csv            every number in the text: the figure as printed, its unrounded value, its period,
                       what it measures, and the formula that computed it from the tables (cell, ratio, rank, median ...)
charts/*.csv           the values each chart draws, one file per chart
tables/panel.csv       Funding and trade side by side, 36 economies
tables/bank-can.csv    Bank loans and deposits, Q2 2026 positions
tables/board.csv       Signal Board: funding vulnerability and flows
tables/country.csv     Country sheets: funding and goods trade by economy
tables/cut-can.csv     Cut a lender, Q2 2026 BIS LBS positions
tables/pair-can.csv    Canada and United States
tables/pair-mex.csv    Mexico and United States
tables/sovereign.csv   Sovereign stress signals
tables/stress.csv      Funding-and-trade stress signals
tables/stress-can.csv  Canada, 2026-Q2

tables/panel.csv is the desk's join of the funding and trade views: one row per economy.

Sources
-------
- BIS, IMF via datasteg money-flow: Signal Board: funding vulnerability and flows
  api.datasteg.com/v1/money-flow/board  (release 20261117.2)
  retrieved 2026-11-17; derived views of open statistics; each publisher's terms apply
- IMF, BIS, OECD via datasteg money-flow: Sovereign stress signals
  api.datasteg.com/v1/money-flow/sovereign  (release 20261117.2)
  retrieved 2026-11-17; derived views of open statistics; each publisher's terms apply
- BIS, IMF, Federal Reserve, UN Comtrade via datasteg global-network: Funding-and-trade stress signals
  api.datasteg.com/v1/global-network/stress  (release 20261117.1)
  retrieved 2026-11-17; derived views of open statistics; each publisher's terms apply
- BIS, IMF, UN Comtrade via datasteg global-network: Country sheets: funding and goods trade by economy
  api.datasteg.com/v1/global-network/countries/{iso3}  (release 20261117.1)
  retrieved 2026-11-17; derived views of open statistics; each publisher's terms apply
- BIS via datasteg money-flow: Bank loans and deposits, Q2 2026 positions
  api.datasteg.com/v1/money-flow/markets/bank?debtor=CAN  (release 20261117.2)
  retrieved 2026-11-17; derived views of open statistics; each publisher's terms apply
- BIS, IMF via datasteg money-flow: Cut a lender, Q2 2026 BIS LBS positions
  api.datasteg.com/v1/money-flow/markets/bank/lender-cut?debtor=CAN&lender=USA&cut_pct=25  (release 20261117.2)
  retrieved 2026-11-17; derived views of open statistics; each publisher's terms apply
- UN Comtrade, BIS, IMF via datasteg global-network: Canada and United States
  api.datasteg.com/v1/global-network/pairs/CAN/USA  (release 20261117.1)
  retrieved 2026-11-17; derived views of open statistics; each publisher's terms apply
- UN Comtrade, BIS, IMF via datasteg global-network: Mexico and United States
  api.datasteg.com/v1/global-network/pairs/MEX/USA  (release 20261117.1)
  retrieved 2026-11-17; derived views of open statistics; each publisher's terms apply
- BIS, IMF, Federal Reserve, UN Comtrade via datasteg global-network: Canada, 2026-Q2
  api.datasteg.com/v1/global-network/stress?economy=CAN  (release 20261117.1)
  retrieved 2026-11-17; derived views of open statistics; each publisher's terms apply

Fetch the latest data again
--------------------------
curl -s "https://api.datasteg.com/v1/money-flow/markets/bank?debtor=CAN&release=20261117.2&format=csv" -o bank-can.csv
curl -s "https://api.datasteg.com/v1/global-network/stress?economy=CAN&format=csv" -o stress-can.csv
curl -s "https://api.datasteg.com/v1/money-flow/markets/bank/lender-cut?debtor=CAN&lender=USA&cut_pct=25&release=20261117.2&format=csv" -o cut-can.csv
curl -s "https://api.datasteg.com/v1/global-network/countries/CAN?format=csv" -o country-can.csv

API documentation: https://www.datasteg.com/en/technology/api
Each publisher's terms apply to its statistics (BIS, IMF, UN Comtrade); cite them with datasteg as the source of the calculation.
