Indonesia's net reserves covered the fewest months of imports in 20 quarters
============================================================================

The data behind this datasteg data note, as the desk read them when it wrote the note.

numbers.csv               every number in the text: the figure as printed, its unrounded value, its period,
                          what it measures, and the formula that computed it from the tables (cell, ratio, rank, median ...)
charts/*.csv              the values each chart draws, one file per chart
tables/panel.csv          Funding and trade side by side, 36 economies
tables/board.csv          Signal Board: funding vulnerability and flows
tables/board-prev.csv     Signal Board, Q1 2026
tables/country.csv        Country sheets: funding and goods trade by economy
tables/sovereign.csv      Sovereign stress signals
tables/stress.csv         Funding-and-trade stress signals
tables/stress-2025q2.csv  Stress signals for the 36 money-flow board economies, 2025-Q2
tables/stress-idn.csv     Indonesia, 2026-Q2

tables/panel.csv is the desk's join of the funding and trade views: one row per economy.

Sources
-------
- BIS, IMF via datasteg money-flow: Signal Board: funding vulnerability and flows
  api.datasteg.com/v1/money-flow/board  (release 20261118.2)
  retrieved 2026-11-18; derived views of open statistics; each publisher's terms apply
- IMF, BIS, OECD via datasteg money-flow: Sovereign stress signals
  api.datasteg.com/v1/money-flow/sovereign  (release 20261118.2)
  retrieved 2026-11-18; derived views of open statistics; each publisher's terms apply
- BIS, IMF, Federal Reserve, UN Comtrade via datasteg global-network: Funding-and-trade stress signals
  api.datasteg.com/v1/global-network/stress  (release 20261118.1)
  retrieved 2026-11-18; derived views of open statistics; each publisher's terms apply
- BIS, IMF, UN Comtrade via datasteg global-network: Country sheets: funding and goods trade by economy
  api.datasteg.com/v1/global-network/countries/{iso3}  (release 20261118.1)
  retrieved 2026-11-18; derived views of open statistics; each publisher's terms apply
- BIS, IMF via datasteg money-flow: Signal Board, Q1 2026
  api.datasteg.com/v1/money-flow/board?quarter=2026-03-31  (release 20261118.2)
  retrieved 2026-11-18; derived views of open statistics; each publisher's terms apply
- BIS, IMF, Federal Reserve, UN Comtrade via datasteg global-network: Stress signals for the 36 money-flow board economies, 2025-Q2
  api.datasteg.com/v1/global-network/stress?quarter=2025-06-30  (release 20261118.1)
  retrieved 2026-11-18; derived views of open statistics; each publisher's terms apply
- BIS, IMF, Federal Reserve, UN Comtrade via datasteg global-network: Indonesia, 2026-Q2
  api.datasteg.com/v1/global-network/stress?economy=IDN  (release 20261118.1)
  retrieved 2026-11-18; derived views of open statistics; each publisher's terms apply

Fetch the latest data again
--------------------------
curl -s "https://api.datasteg.com/v1/money-flow/board?quarter=2026-03-31&release=20261118.2&format=csv" -o board-prev.csv
curl -s "https://api.datasteg.com/v1/global-network/stress?quarter=2025-06-30&format=csv" -o stress-2025q2.csv
curl -s "https://api.datasteg.com/v1/money-flow/board?release=20261118.2&format=csv" -o board.csv
curl -s "https://api.datasteg.com/v1/global-network/stress?economy=IDN&format=csv" -o stress-idn.csv

API documentation: https://www.datasteg.com/en/technology/api
Each publisher's terms apply to its statistics (BIS, IMF, UN Comtrade); cite them with datasteg as the source of the calculation.
